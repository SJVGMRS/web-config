<?php
/* 
 Copyright (C) 2005-2007 Earl C. Terwilliger
 Email contact: earl@micpc.com

 Name : astdel.php 
 Usage: PHP script to delete files, invoked via astdir.php

    This file is part of The Asterisk WEB/PHP Management Interface.

    These files are free software; you can redistribute them and/or modify
    them under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    These programs are distributed in the hope that they will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with these files (see COPYING); if not, write to the:

         Free Software Foundation, Inc.
         59 Temple Place
         Suite 330
         Boston, MA  02111-1307
         USA
*/

include('header.php');

$file = "";
$path = "";

if (isset($_POST['file'])) $file = $_POST['file'];
if (isset($_GET['file']))  $file = $_GET['file'];

if ($file != "") {
 if (file_exists($file)) $rc = unlink($file);
 if ($rc)  echo "<br>" . $file . " deleted!<BR>";
 else echo "An error occured in deletion. Make sure the proper permissions are in place.<BR>";
}

if (isset($_POST['path'])) $path = $_POST['path'];
if (isset($_GET['path']))  $path = $_GET['path'];

if ($path != "") {
 if (file_exists($path)) $rc = unlink($path);
 if ($rc)  echo "<br>" . $path . " deleted!<BR>";
 else echo "An error occured in deletion. Make sure the proper permissions are in place.<BR>";
}

?>
