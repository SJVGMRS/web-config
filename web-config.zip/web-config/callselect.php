<?php
/* 
 Copyright (C) 2006 Earl C. Terwilliger
 Email contact: earl@micpc.com

 Name : callselect.php 
 Usage: PHP script to select source / destination of  a call via the web to Asterisk 
        This script invokes placecall.php

    This file is part of The Asterisk WEB/PHP Management Interface.

    These files are free software; you can redistribute them and/or modify
    them under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    These programs are distributed in the hope that they will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with these files (see COPYING); if not, write to the:

         Free Software Foundation, Inc.
         59 Temple Place
         Suite 330
         Boston, MA  02111-1307
         USA
*/

include('header.php');
include('files.php');
?>
<script language='JavaScript'>
<!--
function submitForm ()
{
  if ( (document.cform.channel.value != "") && (document.cform.exten.value != "") &&
       (document.cform.channel.value != document.cform.exten.value) )
  {
      document.cform.onsubmit = function onSubmit(event) { return true; };
      return;
  }
  if ( (document.cform.channel.value != "") && (document.cform.dialdest.value != "")  )
  {
      document.cform.exten.value = document.cform.dialdest.value;
      document.cform.onsubmit = function onSubmit(event) { return true; };
      return;
  }
  clear_dest();
}
function change(obj,nid) { 
  if (obj.id == "ButtonSG") return;
  if (obj.id == "ButtonDG") return;
  obj.id=nid;
} 
function select_src(src,sip,context)
{
  if (document.cform.channel.value != "") reset_form();
  document.cform.channel.value = sip;
  loc = sip.indexOf("/");
//  document.cform.callerid.value = sip.substring(loc+1);
  document.cform.callerid.value = src.name.substring(1);
  document.cform.context.value = context;
  src.id = "ButtonSG";
  if (document.cform.dialdest.value != "") submitForm();
}
function select_dest(dst,sip)
{
  document.cform.exten.value = sip;
  document.cform.dialdest.value = sip;
  dst.id = "ButtonDG";
  submitForm();
}
function clear_dest()
{
  if (document.cform.exten.value != "") { 
    dst = document.getElementById('ButtonDG');
    if (dst != null) dst.id = 'ButtonR';
  }
  document.cform.exten.value = "";
}
function reset_form()
{
  if (document.cform.channel.value != "") { 
    src = document.getElementById('ButtonSG');
    if (src != null) src.id = 'ButtonB';
  }
  if (document.cform.exten.value != "") { 
    dst = document.getElementById('ButtonDG');
    if (dst != null) dst.id = 'ButtonR';
  }
  document.cform.channel.value = "";
  document.cform.exten.value = "";
  document.cform.callerid.value = "";
  document.cform.context.value = "";
  document.cform.dialdest.value = "";
  document.cform.reset();
}
-->
</script>

<style type='text/css'>
<!--
#ButtonB  { width: 100px; height: 25px;
            font-family: Helvetica, Arial, sans-serif;
            font-size: 10px; font-weight: bold;
            text-align: center; border: none;
            background-color:#000099;    color:white;   }
#ButtonR  { width: 100px; height: 25px;
            font-family: Helvetica, Arial, sans-serif;
            font-size: 10px; font-weight: bold;
            text-align: center; border: none;
            background-color:#990000;    color:white;   }
#ButtonY  { width: 100px; height: 25px;
            font-family: Helvetica, Arial, sans-serif;
            font-size: 10px; font-weight: bold;
            text-align: center; border: none;
            background-color:#FFFF00;    color:black;   }
#ButtonSG { width: 100px; height: 25px;
            font-family: Helvetica, Arial, sans-serif;
            font-size: 10px; font-weight: bold;
            text-align: center; border: none;
            background-color:#003300;    color:white;   }
#ButtonDG { width: 100px; height: 25px;
            font-family: Helvetica, Arial, sans-serif;
            font-size: 10px; font-weight: bold;
            text-align: center; border: none;
            background-color:#003300;    color:white;   }
-->
</style>
<center>
<form name=cform method=post action=placecall.php onSubmit="return false;">
 <input type=hidden name=channel  value=''></input>
 <input type=hidden name=exten    value=''></input>
 <input type=hidden name=context  value=''></input>
 <input type=hidden name=callerid value=''></input>
<table cellspacing=2 cellpadding=2 border=0>
<tr>
<th>SOURCE</th>
<?php
 $fname = $ASTSIPFILE;

 $fd = fopen ($fname, "r");
 if (!$fd) { echo "Error opening $fname"; exit(0); }

 $user    = array();
 $context = array();
 $exten   = array();
 $c = $u = $e = $sc = "";

 while (!feof ($fd)) {
   $buffer = fgets($fd, 4096);
   $l = trim($buffer);
//   $pattern = '/^\s*;/';
//   if (preg_match($pattern,$l,$matches)) { print_r($matches); echo "<br>"; }
     $pattern = '/^\s*\[(.*?)\]\(\!\)/';
     if (preg_match($pattern,$l,$matches)) {
       continue;
     }
     $pattern = '/^\s*\[(.*?)\]/';
     if (preg_match($pattern,$l,$matches)) {
       if (($u != "") && ($c != "") && ($e != "")) {
         $context[] = $c;
         $user[]    = $u;
         $exten[]   = $e;
       }
       $u = $e = "";
       $c = $sc;
     }
//   $pattern = '/^\s*(\w+)\s*=>\s*(.+)\s*;?.*$/';
//   if (preg_match($pattern,$l,$matches)) { print_r($matches); echo "<br>"; }
   $pattern = '/^\s*(\w+)\s*=\s*(.+)\s*;?.*$/';
   if (preg_match($pattern,$l,$matches)) {
      if ($matches[1] == "context")  { $sc = $c = $matches[2]; }
      if ($matches[1] == "username") {       $u = $matches[2]; }
      if ($matches[1] == "regexten") {       $e = $matches[2]; }
   }
 }
 fclose ($fd); 
 if (($u != "") && ($c != "") && ($e != "")) {
   $context[] = $c;
   $user[]    = $u;
   $exten[]   = $e;
 }
 foreach ($user as $key => $value) {
   if ( (($key %  6) == 0) && ($key != 0) ) echo "</tr><tr><th>&nbsp;</th>";
   echo "<td><button name='s" . $exten[$key] . "' onMouseOver='change(this,\"ButtonY\")'\n";
   echo "     onMouseOut='change(this,\"ButtonB\")' id='ButtonB'\n";
   echo "     onClick='select_src(this,\"sip/" . $value . "\",\"" . $context[$key] . "\");'>";
   echo strtoupper($value) . "</button>\n";
   echo "</td>\n";
 }
 echo "</tr><tr><th>DESTINATION</th>";
 foreach ($user as $key => $value) {
   if ( (($key %  6) == 0) && ($key != 0) ) echo "</tr><tr><th>&nbsp;</th>";
   echo "<td><button name='d" . $exten[$key] . "' onMouseOver='change(this,\"ButtonY\")'\n";
   echo "     onMouseOut='change(this,\"ButtonR\")' id='ButtonR'\n";
   echo "     onClick='select_dest(this,\"" . $exten[$key] . "\");'>" . strtoupper($value);
   echo "</button>\n";
   echo "</td>\n";
 }
 echo "</tr><tr><th>&nbsp;</th>";
 echo "<td><button name='d8000' onMouseOver='change(this,\"ButtonY\")'\n";
 echo "     onMouseOut='change(this,\"ButtonR\")' id='ButtonR'\n";
 echo "     onClick='select_dest(this,\"8000\");'>VOICEMAIL</button>\n";
 echo "</td>\n";
 echo "</tr>";
?>
</table>
<br><br>
 <input type="submit" value="Submit" onClick="submitForm()">
 &nbsp;&nbsp;&nbsp;&nbsp;
 <input type="reset" value="Reset" onClick="reset_form()">
 &nbsp;&nbsp;&nbsp;&nbsp;
 [Call Type]
 &nbsp;&nbsp;
 Manager&nbsp;<input type=radio name=calltype value="mgr" checked>
 &nbsp;
 File   &nbsp;<input type=radio name=calltype value="file">
 &nbsp;&nbsp;&nbsp;&nbsp;
 DIAL DESTINATION:&nbsp;
 <input type=text name=dialdest size=15 value=''></input>

</form>
<p>Click on a Source Button, then Click a Destination button. Or Click on a Source Button, type in a dial destination number then click on Submit.</p>
</center>
</body>
</html>
