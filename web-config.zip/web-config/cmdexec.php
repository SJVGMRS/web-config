<?php
/* 
 Copyright (C) 2005-2007 Earl C. Terwilliger
 Email contact: earl@micpc.com

 Name : cmdexec.php 
 Usage: PHP script to interact with the Asterisk Manager Interface
        needs the login.php script to provide info from /etc/asterisk/manager.conf

    This file is part of The Asterisk WEB/PHP Management Interface.

    These files are free software; you can redistribute them and/or modify
    them under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    These programs are distributed in the hope that they will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with these files (see COPYING); if not, write to the:

         Free Software Foundation, Inc.
         59 Temple Place
         Suite 330
         Boston, MA  02111-1307
         USA
*/
include('header.php');
echo '<pre>';
$logoff   = "Action: Logoff\r\n\r\n";
$cmd      = "";
$parms    = "";
$wrets    = "";

if (isset($_GET['cmd']))     $cmd   = $_GET['cmd'];
if (isset($_POST['cmd']))    $cmd   = $_POST['cmd'];
if (isset($_GET['parms']))   $parms = $_GET['parms'];
if (isset($_POST['parms']))  $parms = $_POST['parms'];

include('login.php');

if ($cmd == "command") {
  if ($parms != "") {
     if (strtolower(substr($parms,0,7)) != "command") {
       $parms = "Command: " . $parms; 
     }     
  }
}

if ($cmd != "")   $cmd  = "Action: " . $cmd;
else {
  $cmd  = "Action: ListCommands";
  $parms = "";
}

echo "ASTERISK MANAGER INPUT\n";
echo "COMMAND: ".$cmd."\n";
echo "PARMS  : ".$parms."\n\n";

if ($parms != "") {
    $cmd = $cmd . "\r\n";
    $parms = $parms . "\r\n\r\n";
}
else $cmd = $cmd . "\r\n\r\n";

fputs($socket, $cmd);
if ($parms != "") fputs($socket,$parms);
fputs($socket, $logoff);

echo "ASTERISK MANAGER OUTPUT\n";
flush();

if (strtolower(substr($parms,0,13)) == "command: help") {
  $resp = 0;
  $data = "";
  while (!feof($socket)) $data .= fread($socket, 4096);
  $e = explode("\n",$data);
  while (list($arg, $val) = each($e)) {
    if (substr($val,0,15) == "--END COMMAND--") {
      $resp = 0; 
      echo $val;
      echo "\n"; 
      flush();
      continue;
    }
    if (strpos($val,":")) {
      if (substr($val,0,17) == "Response: Follows") $resp = 1;
      echo $val;
      echo "\n"; 
      flush();
      continue;
    } 
/*
    if ($resp == 1) {
      $l  = "<a href=cmdexec.php?cmd=command&parms=Command:%20";
      $l .= urlencode(trim(substr($val,0,25)));
      $l .= ">" . substr($val,0,25) . "</a>" . substr($val,25);
      echo $l;
    }
*/
    if ($resp) {
      $l = trim($val);
      $ary = explode(" ",$l);
      $ul = "";
      $s  = 0;
      foreach($ary as $akey => $aval) {
        if (($s !=1) && (strtoupper(substr($aval,0,1)) == substr($aval,0,1))) {        
           echo "<a href=cmdexec.php?cmd=command&parms=Command:%20";
           echo urlencode($ul) . ">" . $ul . "</a> ";
           $ul = "";
           $s = 1;
        }
        $ul .= $aval . " ";
      }
      echo $ul;
    }
    else echo $val;
    echo "\n";
    flush();
  }
  fclose($socket);
  echo '</pre>';
  exit();
}
if (strtolower(substr($cmd,0,20)) == "action: listcommands") {
  $resp = 0;
  $data = "";
  while (!feof($socket)) $data .= fread($socket, 4096);
  $e = explode("\n",$data);
  while (list($arg, $val) = each($e)) {
    $cmd = trim($val);
    if (substr($cmd,0,17) == "Response: Success") {
      $resp += 1;
      echo $val;
      echo "\n"; 
      flush();
      continue;
    } 
    if (substr($cmd,0,17) == "Response: Goodbye") {
      $resp = 0;
      echo $val;
      echo "\n"; 
      flush();
      continue;
    } 
    if ($resp == 2) {
      $p1 = strpos($val,substr($cmd,0,1));
      $p2 = strpos($cmd,":");
      $app = substr($cmd,0,$p2);
      $l  = substr($val,0,$p1);
      $l  = "<a href=cmdexec.php?cmd=";
      $l .= urlencode($app);
      $l .= "&parms=";
      $l .= ">";                                            
      $l .= $app;
      $l .= "</a>";
      $l .= substr($val,$p1+strlen($app));
      echo $l;
    }
    else echo $val;
    echo "\n";
    flush();
  }
  fclose($socket);
  echo '</pre>';
  exit();
}
if (strtolower(substr($parms,0,26)) == "command: show applications") {
  $resp = 0;
  $data = "";
  while (!feof($socket)) $data .= fread($socket, 4096);
  $e = explode("\n",$data);
  while (list($arg, $val) = each($e)) {
    $cmd = trim($val);
    if (substr($cmd,0,2) == "-=") {
      if ($resp == 0) $resp = 1;
      else $resp = 0;
      echo $val . "\n";
      flush(); 
      continue;
    }
    if ($resp == 1) {
      $p1 = strpos($val,substr($cmd,0,1));
      $p2 = strpos($cmd,":");
      $app = substr($cmd,0,$p2);
      $l  = substr($val,0,$p1);
      $l  = "<a href=cmdexec.php?cmd=command&parms=Command:%20Show%20Application%20";
      $l .= urlencode($app);
      $l .= ">";                                            
      $l .= $app;
      $l .= "</a>";
      $l .= substr($val,$p1+strlen($app));
      echo $l;
    }
    else echo $val;
    echo "\n";
    flush();
  }
  fclose($socket);
  echo '</pre>';
  exit();
}
while (!feof($socket)) { echo fread($socket, 2048);  flush(); }
fclose($socket);
echo '</pre>';
?>
