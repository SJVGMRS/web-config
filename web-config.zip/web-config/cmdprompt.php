<?php
/* 
 Copyright (C) 2005-2007 Earl C. Terwilliger
 Email contact: earl@micpc.com

 Name : cmdprompt.php 
 Usage: PHP script which creates menus for fields to complete a command which
        will be sent to cmdexec.php 

    This file is part of The Asterisk WEB/PHP Management Interface.

    These files are free software; you can redistribute them and/or modify
    them under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    These programs are distributed in the hope that they will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with these files (see COPYING); if not, write to the:

         Free Software Foundation, Inc.
         59 Temple Place
         Suite 330
         Boston, MA  02111-1307
         USA
*/

$novars = FALSE;

if (isset($_GET['prompt'])) {
  if ($_GET['prompt'] == "") {
    $hdr = "Location: cmdexec.php?";
    while (list($name, $value) = each($HTTP_GET_VARS)) {
      if ($name == "cmd") {
         $hdr = $hdr . "cmd=" . htmlentities($value);
         continue;
      }
      if ($name == "parms") {
         $hdr = $hdr . "&parms=" . htmlentities($value);
          continue;
      }
    }
    header($hdr);
    exit(0);
  }
}
if (isset($_POST['submit'])) {
  $hdr = "Location: cmdexec.php?";
  while (list($name, $value) = each($_POST)) {
    if ($name == "submit") continue;
    if ($name == "cmd") {
       $hdr = $hdr . "cmd=" . htmlentities($value);
       continue;
    }
    if ($name == "parms") {
       $hdr = $hdr . "&parms=" . htmlentities($value);
        continue;
    }
    if ($name == "vars") {
        if (strtolower($value) == "no") $novars = TRUE;
        continue;
    }
    
    if ($value == "") continue;
    if (substr($hdr,-1,1) != "=") {
      if ($novars) $hdr = $hdr . htmlentities(" ");
      else         $hdr = $hdr . htmlentities("%0d%0a");
    }
    if ($novars) $hdr = $hdr . htmlentities($value);
    else         $hdr = $hdr . $name . htmlentities(": ") . htmlentities($value);
  }
//  echo $hdr;
  header($hdr);
  exit(0);
}
else {
    include('header.php');
?>
<center>
<H1>ASTERISK CMD INTERFACE PROMPT FOR MISSING INFO</H1>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<input type=hidden name="cmd"    value="<?php echo $_GET['cmd']; ?>">
<input type=hidden name="parms"  value="<?php echo $_GET['parms']; ?>">
<?php
if (isset($_GET['vars'])) {
  echo "<input type=hidden name=\"vars\" value=\"";
  echo $_GET['vars'];
  echo "\">";
}
?>
<table>
<?php
 $delim = ",";
 if (isset($_GET['prompt'])) {
    $e = explode($delim,$_GET['prompt']);
    $ln = count($e);
    for ($c=0;$c<$ln;++$c) {
      echo "<tr>";
      echo "<td>" . $e[$c] . "&nbsp;&nbsp;</td>";
      echo "<td>" . "<input type=\"text\" name=\"" . $e[$c] . "\" size=\"30\">" . "</td>";
      echo "</tr>";
    }
 }
?>
</table>
<br>
<input type="submit" name="submit" value="Submit">&nbsp;&nbsp;
<input type="reset"  value="Reset">
</form>
</center>
<?php } ?>
