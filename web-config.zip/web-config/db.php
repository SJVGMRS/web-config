<?PHP
/* 
 Copyright (C) 2005-2007 Earl C. Terwilliger
 Email contact: earl@micpc.com

 Name : db.php
 Usage: PHP script to create a form and to manage the asterisk database

    This file is part of The Asterisk WEB/PHP Management Interface.

    These files are free software; you can redistribute them and/or modify
    them under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    These programs are distributed in the hope that they will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with these files (see COPYING); if not, write to the:

         Free Software Foundation, Inc.
         59 Temple Place
         Suite 330
         Boston, MA  02111-1307
         USA
*/

include('files.php');
include('header.php');
include('functions.php');
if (isset($_GET['cidname'])) {
?>
  <center>
  <br>
  <h1>Add Caller ID Name/Number to Asterisk Database</h1>
  <br>
  <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
  <table cellpadding=2>
  <tr>
    <td>Phone number:</td>
    <td><input name="number" size=30></td>
  </tr>
  <tr>
    <td>Name:</td>
    <td><input name="name" size=30></td>
  </tr>
  <tr>
    <td></td>
    <td align=right>
        <input type="reset"  value="Reset">
         &nbsp;&nbsp;&nbsp;&nbsp;
        <input type=submit name=submit value="CID Add">
   </td>
  </tr>
  </table>
  </form>
  </center> 
  </body>
  </html>
<?PHP
  exit();
}
if (isset($_POST['submit'])) {
  $action = "";
  $family = "";
  $key    = "";
  $value  = "";
  $cmd    = "";
  if (isset($_POST['action'])) $action = $_POST['action'];  
  if (isset($_POST['family'])) $family = $_POST['family'];  
  if (isset($_POST['key']))    {
    $key    = $_POST['key'];  
    $value  = "\"" . $_POST['value'] . "\"";
  }
  if ($_POST['submit'] == "CID Add") {
    $phonenumber = $_POST['number'];
    $phonename   = $_POST['name'];
    $cmd = "database put cidname $phonenumber \"$phonename\"";
  }
  if ($action == "get")     $cmd = "database get $family $key";
  if ($action == "add")     $cmd = "database put $family $key $value";
  if ($action == "delete")  $cmd = "database del $family $key";
  if ($action == "deltree") $cmd = "database deltree $family";
  if ($action == "show")    $cmd = "database show";
  if ($action == "cid")     $cmd = "database show cidname";
  if ($cmd != "") {
    echo "<pre>";
    echo "asterisk -rx $cmd<br><br>\n";
    astersys($cmd);
    echo "<br></pre>\n";
    exit(0);
  }
  echo "<br>Nothing to do!<br>";
  echo "</body>";
  echo "</html>";
  exit(0);
}
else {
?>
<center>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<input type="submit" name="submit" value="Submit">&nbsp;&nbsp;
<input type="reset"  value="Reset">
<br>
<br>
<table border=0>
<tr>
<td colspan=2>
<input type=radio name=action value="add">Add</input>
&nbsp;&nbsp;
<input type=radio name=action value="delete">Delete</input>
&nbsp;&nbsp;
<input type=radio name=action value="deltree">Delete Tree</input>
&nbsp;&nbsp;
<input type=radio name=action value="get">Get</input>
&nbsp;&nbsp;
<input type=radio name=action value="cid">Show CIDName</input>
&nbsp;&nbsp;
<input type=radio name=action value="show" checked>Show [All]</input>
</td>
</tr>
<td>Family</td>
<td><input type="text" name="family" size="20"></td>
</tr>
<tr>
<td>Key</td>
<td><input type="text" name="key" size="20"></td>
</tr>
<tr>
<td>Value</td>
<td><input type="text" name="value" size="20"></td>
</tr>
</table>
<br>
</form>
</center> 
</body>
</html>
<?php
 exit();
 }
?>

<?php
//header("Location: cmdexec.php?cmd=command&parms=Command:%20database%20show");
//include("header.php");

//$fname = $ASTDB

//$id = dba_open($fname, "r", "flatfile");
//if (!$id) {
//   echo "Open failed for $fname\n";
//   exit();
//}
//$key   = dba_firstkey($id);
//$data  = dba_fetch($key,$id);
//while ($key != false) {
//  echo "key  : $key  <br>";
//  echo "data : $data <br>";
//  $key = dba_nextkey($id);
//}
//dba_close($id);

//$file = fopen($fname, 'r');
//if ($file == FALSE) {
//  echo "<BR>Error opening $fname<BR>";
//  echo "Make sure the web server has authority to read this file!<BR>";
//  exit();
//}
//$contents = fread($file, filesize ($fname));
//echo "<pre>";
//echo $contents;
//echo "</pre>";
//fclose($file);

//system("asterisk -R -x 'database show'\" > /tmp/astdb.txt");
//$file = fopen("/tmp/astdb.txt","r");
//while ($line=fgets($file,4096)) {
//    $data .= $line;
//}
//$data = str_replace("\n", "<br>", $data); 
//echo $data;
//fclose($file);
?>
