<?php
/* 
 Copyright (C) 2005-2007 Earl C. Terwilliger
 Email contact: earl@micpc.com

 Name : files.php 
 Usage: PHP script which has all the variable Asterisk file names
        this is included from other PHP scripts 

    This file is part of The Asterisk WEB/PHP Management Interface.

    These files are free software; you can redistribute them and/or modify
    them under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    These programs are distributed in the hope that they will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with these files (see COPYING); if not, write to the:

         Free Software Foundation, Inc.
         59 Temple Place
         Suite 330
         Boston, MA  02111-1307
         USA
*/
$ASTERCMD       = "/usr/sbin/asterisk -rx";
$ASTMANAGERFILE = "/etc/asterisk/manager.conf";
$ASTSIPFILE     = "/etc/asterisk/sip.conf";
$VMHOME         = "/var/spool/asterisk/voicemail";
$SNDHOME        = "/var/lib/asterisk/sounds";
$AGIHTML        = "/var/www/html/asterisk/agihtml.html";
$ASTCONFIGPATH  = "/etc/asterisk";
$CDRMASTER      = "/var/log/asterisk/cdr-csv/Master.csv";
$TFTPBOOTDIR    = "/tftpboot";
$ASTLIBDIR      = "/var/lib/asterisk";
$ASTDB          = "/var/lib/asterisk/astdb";
$ASTSPOOLDIR    = "/var/spool/asterisk";
$ASTFAXDIR      = "/var/spool/asterisk/fax";
$ASTLOGDIR      = "/var/log/asterisk";
$ASTWEBDIR      = "/var/www/html/asterisk";
$VMAILCGI       = "vmail.cgi";
$ABSWEBCGIDIR   = "/var/www/cgi-bin";
$WEBCGIDIR      = "/cgi-bin";
$SYSTEMMESSAGES = "/var/log/messages";
$ASTEVENTLOG    = "/var/log/asterisk/event_log";
$ASTMESSAGESLOG = "/var/log/asterisk/messages";
$ASTQUEUELOG    = "/var/log/asterisk/queue_log";
$ASTOUTGOINGDIR = "/var/spool/asterisk/outgoing";
$ASTERSTART     = "/var/www/html/asterisk/scripts/asterstart.py";
$ASTERKILL      = "/var/www/html/asterisk/scripts/asterkill.sh";
$TMPDIR         = "/tmp/";
?>
