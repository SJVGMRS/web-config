<?php
/* 
 Copyright (C) 2005-2011 Earl C. Terwilliger
 Email contact: earl@micpc.com

 Name : header.php
 Usage: HTML/JAVA Script/Header file to include in all PHP scripts
        creates the common menu and overall page design

    This file is part of The Asterisk WEB/PHP Management Interface.

    These files are free software; you can redistribute them and/or modify
    them under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    These programs are distributed in the hope that they will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with these files (see COPYING); if not, write to the:

         Free Software Foundation, Inc.
         59 Temple Place
         Suite 330
         Boston, MA  02111-1307
         USA
*/
?>
<TITLE>
Asterisk Config File Editing Interface
</TITLE>
<SCRIPT LANGUAGE="JavaScript" SRC="java/JSCookMenu.js"></SCRIPT>
<link rel="stylesheet" type="text/css" href="style/style.css">
<link rel="stylesheet" type="text/css" href="theme/theme.css">
<SCRIPT LANGUAGE="JavaScript" SRC="theme/theme.js"></SCRIPT>
<SCRIPT LANGUAGE="JavaScript" SRC="java/cmds.php"></script>
<div align=center>
<a href=index.php><img width="93" height="128" src=images/asterisk-logo.gif border=0></img></a>
&nbsp;&nbsp;  
<!-- <a href=cmdexec.php?cmd=command&parms=Command:%20reload>Reload</a>
&nbsp;&nbsp;  
<a href=sysexec.php?cmd=asterisk%20&>Start</a>
&nbsp;&nbsp;  
<a href=cmdexec.php?cmd=command&parms=Command:%20stop%20now>Stop</a>
&nbsp;&nbsp;  
<a href=sysexec.php?cmd=killall+-9+asterisk>Kill</a>
&nbsp;&nbsp;  
<a href=cmdexec.php?cmd=Ping&parms=>Ping</a>
&nbsp;&nbsp;  
<a href=cmdexec.php?cmd=command&parms=Command:%20Help>Help</a>-->
<?php
 include('files.php');
 if (file_exists($ASTERKILL)) {
  echo "&nbsp;&nbsp;";
  echo "<a href=sysexec.php?cmd=$ASTERKILL>AsterKill</a>";
 }
 if (file_exists($ASTERSTART)) {
  echo "&nbsp;&nbsp;";
  echo "<a href=sysfork.php?cmd=$ASTERSTART>AsterStart</a>";
 }
?>
&nbsp;&nbsp;  
<br>
</div>
<DIV ID=myMenuID align=center>
<SCRIPT LANGUAGE="JavaScript">cmDraw ('myMenuID', myMenu, 'hbr', cmThemeOffice, 'ThemeOffice');
</SCRIPT>
</DIV>
<br>
