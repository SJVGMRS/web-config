<?php
/* 
 Copyright (C) 2005-2007 Earl C. Terwilliger
 Email contact: earl@micpc.com

 Name : index.php
 Usage: main web page and starting point

    This file is part of The Asterisk WEB/PHP Management Interface.

    These files are free software; you can redistribute them and/or modify
    them under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    These programs are distributed in the hope that they will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with these files (see COPYING); if not, write to the:

         Free Software Foundation, Inc.
         59 Temple Place
         Suite 330
         Boston, MA  02111-1307
         USA
*/
 include('header.php')
?>
<center>
<font color=black><H1>Asterisk Config File Editing Interface</H1></font>
<div align=center>
<table border=1>
<tr>
  <td><a href=index.php>HOME</a></td>
  <td>Return to the Main Menu</td></tr>
<tr>
  <td><a href=dirselect.php>EDIT</a></td>
  <td>Edit Asterisk Configuration Files</td></tr>
</table>
</div>
</body>
</html>
