<?php
/*

 Copyright (C) 2005-2011 Earl C. Terwilliger
 Email contact: earl@micpc.com

 Name : help.php
 Usage: Returns javascripts commands for JSCookMenu.js derived from
        manager help commands

    This file is part of The Asterisk WEB/PHP Management Interface.

    These files are free software; you can redistribute them and/or modify
    them under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    These programs are distributed in the hope that they will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with these files (see COPYING); if not, write to the:

         Free Software Foundation, Inc.
         59 Temple Place
         Suite 330
         Boston, MA  02111-1307
         USA

*/

if (!isset($filter)) $filter = "";

$logoff   = "Action: Logoff\r\n\r\n";
$cmd      = "Action: Command\r\n";
$parms    = "Command: Help\r\n\r\n";

include('../login.php');

fputs($socket, $cmd);
fputs($socket,$parms);
fputs($socket, $logoff);

$resp = 0;
$data = "";

while (!feof($socket)) $data .= fread($socket, 4096);
fclose($socket);

$e = explode("\n",$data);

while (list($arg, $val) = each($e)) {
  if (substr($val,0,15) == "--END COMMAND--") { $resp = 0; continue; }
  if (strpos($val,":")) { if (substr($val,0,17) == "Response: Follows") $resp = 1; continue; }
  if ($resp) {
    $l = trim($val);
    if ($filter != "") { $pos = stripos($l,$filter); if ($pos === false) continue; if ($pos != 0) continue; }
    print("['','");
    $ary = explode(" ",$l);
    $ul = "";
    foreach($ary as $akey => $aval) {
      if (strtoupper(substr($aval,0,1)) == substr($aval,0,1)) break;
      $ul .= $aval . " ";
    }
    echo addslashes($ul);
    echo "','cmdexec.php?cmd=command&parms=Command:+";
    echo urlencode(addslashes($ul));
    echo "','','";
    echo addslashes($l);
    print ("'],\n");
    continue;
  }

}
?>
