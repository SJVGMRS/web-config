<?php
/* 
 Copyright (C) 2005-2007 Earl C. Terwilliger
 Email contact: earl@micpc.com

 Name : logs.php 
 Usage: PHP script to provide a selection form to list system and Asterisk logs

    This file is part of The Asterisk WEB/PHP Management Interface.

    These files are free software; you can redistribute them and/or modify
    them under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    These programs are distributed in the hope that they will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with these files (see COPYING); if not, write to the:

         Free Software Foundation, Inc.
         59 Temple Place
         Suite 330
         Boston, MA  02111-1307
         USA
*/

if (isset($_POST['radio'])) {
  if ($_POST['radio'] == "cdrformat") {
    if (isset($_POST['pattern']))  $pattern = $_POST['pattern'];      
    header("Location: cdr.php?pattern=$pattern");
//  header("Location: http://$_SERVER/asterisk/cdr.php?pattern=$pattern");
  }
}

include('header.php');
include('files.php');
include('functions.php');

if (isset($_POST['submit'])) {
    $submit = $_POST['submit'];      
    if (isset($_POST['loglines'])) $loglines = $_POST['loglines'];      
    else $loglines = 0;
    if (isset($_POST['pattern']))  $pattern  = $_POST['pattern'];      
    else $pattern = "";
    if (isset($_POST['radio']))    $radio    = $_POST['radio'];      
 if ($submit =="SUBMIT") {
    if ($pattern != "") $cmd = "/bin/grep  $pattern ";
    else {
       if ($loglines == 0) $cmd = "/bin/cat ";
       else                $cmd = "/usr/bin/tail -$loglines ";
    }
    if ($radio == "syslog")   $cmd .= $SYSTEMMESSAGES;
    if ($radio == "cdr")      $cmd .= $CDRMASTER;
    if ($radio == "events")   $cmd .= $ASTEVENTLOG;
    if ($radio == "messages") $cmd .= $ASTMESSAGESLOG;
    if ($radio == "queue")    $cmd .= $ASTQUEUELOG;
    echo "<pre>";
    mysystem($cmd);
    echo "</pre>";
    echo "<br>";
    echo $cmd;
    echo "<br>";
    echo "Done !";
 }
}
else
{
?>
  <div align=center>
  <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
  <table>
    <tr><td>
    Search String&nbsp;<input type=text name="pattern" value="" length=20>
    </td><td>
    &nbsp;&nbsp;&nbsp;&nbsp;
    Lines to List [0=All]&nbsp;<input type=text name="loglines" value=50 length=3>
    </td></tr>
  </table>

  <table>
  <tr><td>
  <input type="radio" name="radio" value="events">&nbsp;Asterisk Event Log
  </td><td>&nbsp;</td></tr>

  <tr><td>
  <input type="radio" name="radio" value="messages">&nbsp;Asterisk Message Log
  </td><td>&nbsp;</td></tr>

  <tr><td>
  <input type="radio" name="radio" value="queue">&nbsp;Asterisk Queue Log
  </td><td>&nbsp;</td></tr>

  <tr><td>
  <input type="radio" name="radio" value="cdr">&nbsp;Asterisk CDR Log
  </td><td>&nbsp;</td></tr>

  <tr><td>
  <input type="radio" name="radio" value="cdrformat">&nbsp;Asterisk CDR Log [Table Formatted]
  </td><td>&nbsp;</td></tr>

  <tr><td>
  <input type="radio" name="radio" value="syslog" checked>&nbsp;System Log [SYSLOG]
  </td><td>
  &nbsp;
  </td></tr>

  </table>
  <br>
  <input type="submit" name="submit" value="SUBMIT"></input>
  &nbsp;&nbsp;
  <input type="reset" name="reset" value="RESET"></input>
  </form>
  </div>
<?php
}
?>
