<?php
/* 
 Copyright (C) 2005-2007 Earl C. Terwilliger
 Email contact: earl@micpc.com

 Name : manager.php 
 Usage: PHP script to provide an easy selection via a form to the various
        Asterisk Manager Interface commands

    This file is part of The Asterisk WEB/PHP Management Interface.

    These files are free software; you can redistribute them and/or modify
    them under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    These programs are distributed in the hope that they will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with these files (see COPYING); if not, write to the:

         Free Software Foundation, Inc.
         59 Temple Place
         Suite 330
         Boston, MA  02111-1307
         USA
*/
include('header.php');
?>

<form method="post" action="cmdexec.php">
<div align=center>
<input type="submit" name="submit" value="Submit"></input>
&nbsp;&nbsp;&nbsp;&nbsp;
<input type="reset"  name="reset"  value="Reset"></input>
</div>
<br>
<table border=1>
<tr>
  <td>
    <input type="radio" name="cmd" value="absolutetimeout">
    <a href=cmdprompt.php?cmd=absolutetimeout&parms=&prompt=Channel,Timeout
>Set Absolute Timeout</a>
  </td>
  <td><input type="radio" name="cmd" value="changemonitor">
    <a href=cmdprompt.php?cmd=ChangeMonitor&parms=&prompt=Channel,Filename>
    ChangeMonitor: Change monitoring filename of a channel
</a>
  </td>
  <td><input type="radio" name="cmd" value="command">
    <a href=cmdprompt.php?cmd=command&parms=&prompt=Command>
    Command: Execute Command
</a>
  </td>
</tr>
<tr>
  <td><input type="radio" name="cmd" value="events">
    <a href=cmdprompt.php?cmd=Events&parms=&prompt=Event>
   Events: Contol Event Flow
</a>
  </td>
  <td><input type="radio" name="cmd" value="extensionstate">
    <a href=cmdprompt.php?cmd=ExtensionState&parms=&prompt=Extension>
   ExtensionState: Check Extension Status
</a>
  </td>
  <td><input type="radio" name="cmd" value="getvar">
    <a href=cmdprompt.php?cmd=Getvar&parms=&prompt=Channel,Variable>
    Getvar: Gets a Channel Variable
</a>
  </td>
</tr>
<tr>
  <td><input type="radio" name="cmd" value="hangup">
    <a href=cmdprompt.php?cmd=Hangup&parms=&prompt=Channel>
    Hangup: Hangup Channel
</a>
  </td>
  <td><input type="radio" name="cmd" value="iaxpeers">
    <a href=cmdprompt.php?cmd=IAXPeers&parms=&prompt=>
    IAXpeers: List IAX Peers
</a>
  </td>
  <td><input type="radio" name="cmd" value="ListCommands">
    <a href=cmdprompt.php?cmd=ListCommands&parms=&prompt=>
    ListCommands: List available manager commands
</a>
  </td>
</tr>
<tr>
  <td><input type="radio" name="cmd" value="logoff">
    <a href=cmdprompt.php?cmd=Logoff&parms=&prompt=>
    Logoff: Logoff Manager
</a>
  <td><input type="radio" name="cmd" value="mailboxcount">
    <a href=cmdprompt.php?cmd=MailboxCount&parms=&prompt=Mailbox>
    MailboxCount: Check Mailbox Message Count
</a>
  </td>

  <td><input type="radio" name="cmd" value="mailboxstatus">
    <a href=cmdprompt.php?cmd=MailboxStatus&parms=&prompt=Mailbox>
    MailboxStatus: Check Mailbox
</a>
  </td>
</tr>
<tr>
  <td><input type="radio" name="cmd" value="monitor">
    <a href=cmdprompt.php?cmd=Monitor&parms=&prompt=Channel>
    Monitor: Monitor a channel
</a>
  </td>
  <td><input type="radio" name="cmd" value="originate">
    <a href=cmdprompt.php?cmd=Originate&parms=&prompt=Channel,Exten,Context,Priority,Timeout,Callerid,Variable,Account,Application,Data,Async,ActionID>
    Originate: Originate Call
</a>
  </td>
  <td><input type="radio" name="cmd" value="parkedcalls">
    <a href=cmdprompt.php?cmd=ParkedCalls&parms=&prompt=>
    ParkedCalls: List parked calls
</a>
  </td>
</tr>
<tr>
  <td><input type="radio" name="cmd" value="ping">
    <a href=cmdprompt.php?cmd=Ping&parms=&prompt=>
    Ping: Ping
</a>
  </td>
  <td><input type="radio" name="cmd" value="queueadd">
    <a href=cmdprompt.php?cmd=QueueAdd&parms=&prompt=Queue,Interface>
    QueueAdd: Add interface to queue.
</a>
  </td>
  <td><input type="radio" name="cmd" value="queueremove">
    <a href=cmdprompt.php?cmd=QueueRemove&parms=&prompt=Queue,Interface>
    QueueRemove: Remove interface from queue.
</a>
  </td>
</tr>
<tr>
  <td><input type="radio" name="cmd" value="queues">
    <a href=cmdprompt.php?cmd=Queues&parms=&prompt=>
    Queues: Queues
</a>
  </td>
  <td><input type="radio" name="cmd" value="queuestatus">
    <a href=cmdprompt.php?cmd=QueueStatus&parms=&prompt=Queue>
    QueueStatus: Queue Status
</a>
  </td>
  <td><input type="radio" name="cmd" value="redirect">
    <a href=cmdprompt.php?cmd=Redirect&parms=&prompt=Channel>
    Redirect: Redirect
</a>
  </td>
</tr>
<tr>
  <td><input type="radio" name="cmd" value="setcdruserfield">
    <a href=cmdprompt.php?cmd=SetCDRUserField&parms=&prompt=Field,Value>
    SetCDRUserField: Set the CDR UserField
</a>
  </td>
  <td><input type="radio" name="cmd" value="setvar">
    <a href=cmdprompt.php?cmd=Setvar&parms=&prompt=Channel,Variable,Value>
    Setvar: Set Channel Variable
</a>
  </td>
  <td><input type="radio" name="cmd" value="status">
    <a href=cmdprompt.php?cmd=Status&parms=&prompt=>
    Status: Status
</a>
  </td>
</tr>
<tr>
  <td><input type="radio" name="cmd" value="stopmonitor">
    <a href=cmdprompt.php?cmd=StopMonitor&parms=&prompt=Channel>
    StopMonitor: Stop monitoring a channel
</a>
  </td>
  <td><input type="radio" name="cmd" value="zapdialoffhook">
    <a href=cmdprompt.php?cmd=ZapDialOffhook&parms=&prompt=Channel>
    ZapDialOffhook: Dial over Zap channel while offhook
</a>
  </td>
  <td><input type="radio" name="cmd" value="zapdndoff">
    <a href=cmdprompt.php?cmd=ZapDNDoff&parms=&prompt=Channel>
    ZapDNDoff: Toggle Zap channel Do Not Disturb status OFF
</a>
  </td>
</tr>
<tr>
  <td><input type="radio" name="cmd" value="zapdndon">
    <a href=cmdprompt.php?cmd=ZapDNDon&parms=&prompt=Channel>
    ZapDNDon: Toggle Zap channel Do Not Disturb status ON
</a>
  </td>
  <td><input type="radio" name="cmd" value="zaphangup">
    <a href=cmdprompt.php?cmd=ZapHangup&parms=&prompt=Channel>
    ZapHangup: Hangup Zap Channel
</a>
  </td>
  <td><input type="radio" name="cmd" value="zapshowchannels">
    <a href=cmdprompt.php?cmd=ZapShowChannels&parms=&prompt=>
    ZapShowChannels: Show status zapata channels
</a>
  </td>
</tr>
<tr>
  <td><input type="radio" name="cmd" value="zaptransfer">
    <a href=cmdprompt.php?cmd=ZapTransfer&parms=&prompt=Channel>
    ZapTransfer: Transfer Zap Channel
</a>
  </td>
</tr>
</table>
<br>
<input type="text"   name="parms" size="80" value="">&nbsp;&nbsp;Parameters</input>
</form>
