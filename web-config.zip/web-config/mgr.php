<?php
/*
 Copyright (C) 2005-2007 Earl C. Terwilliger
 Email contact: earl@micpc.com

 Name : mgr.php     
 Usage: Issue Manager commands to Asterisk and create web page result

    This file is part of The Asterisk WEB/PHP Management Interface.

    These files are free software; you can redistribute them and/or modify
    them under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    These programs are distributed in the hope that they will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with these files (see COPYING); if not, write to the:

         Free Software Foundation, Inc.
         59 Temple Place
         Suite 330
         Boston, MA  02111-1307
         USA
*/
include('header.php');
?>
<h2>Asterisk Status: <?php echo `hostname`; echo " (".$SERVER_ADDR.")"; ?></h2>
<?php
function mysystem($command) {
 $command = "sudo -u root " . $command;
 if (!($p=popen("($command)2>&1","r"))) return "Process Open Error!<br>";
 while (!feof($p)) { $l=fgets($p,4096); $l = trim($l); echo $l; echo "<br>"; flush(); }
 pclose($p);
 flush();
 return;

}
$arr = array(
"Uptime" => "asterisk -rx 'show uptime'",
"Database Connection Status" => "asterisk -rx 'realtime mysql status'",
"Active Channel(s)" => "asterisk -rx 'sip show channels'",
"Working Queues" => "asterisk -rx 'show queues'",
"Registered Phones" => "asterisk -rx 'sip show peers'",
"Zaptel driver info" => "asterisk -rx 'zap show channels'"
);
foreach ($arr as $key => $value) {
?>
<table>
  <tr><td><?php echo $key; ?></td></tr>
  <tr><td>
   <table border="0" >
    <tr><td><pre><?php echo mysystem($value); ?></pre></td></tr>
   </table>
  </td></tr>
</table>
<?php
}
?>
</body>
</html>
