<?php
/* 
 Copyright (C) 2005-2007 Earl C. Terwilliger
 Email contact: earl@micpc.com

 Name : myadmin.php 
 Usage: PHP script to provide an easy interface to common MySQL functions

    This file is part of The Asterisk WEB/PHP Management Interface.

    These files are free software; you can redistribute them and/or modify
    them under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    These programs are distributed in the hope that they will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with these files (see COPYING); if not, write to the:

         Free Software Foundation, Inc.
         59 Temple Place
         Suite 330
         Boston, MA  02111-1307
         USA
*/
function sqlquery($query) {
 $self = $_SERVER['PHP_SELF'];
// $query = mysql_real_escape_string($query);
 $result = mysql_query($query);
 $erno = mysql_errno();
 $err  = mysql_error();
 if ($erno <> 0) {
   echo "<H3>";
   echo "<a href=$self>MAIN MENU</a>";
   echo "&nbsp;&nbsp;&nbsp;&nbsp;"; 
   echo "<a href=\"javascript:history.back()\"><strong>GO BACK</strong></a>";
   echo "&nbsp;&nbsp;&nbsp;&nbsp;"; 
   echo "<a href=$self?userid=''&password=''>LOGOUT</a>";
   echo "</H3>\n";
   echo "<br>";
   echo "Query: " . $query . "<br>\n";
   echo "<br>" . $erno . ": " . $err . "<br>\n";
   echo "</center>";
   echo "</body></html>";
   exit();
 }
 return($result);
}
function make_table($query) {
 $self = $_SERVER['PHP_SELF'];
 $result    = sqlquery($query);
 $count     = mysql_num_rows($result);
 $numfields = mysql_num_fields($result);
 $rows = 0;
 $lastfield = "";

 echo "<b><H2>" . $query . "</H2></b>\n";
 echo "<H3>";
 echo "<a href=$self>MAIN MENU</a>";
 echo "&nbsp;&nbsp;&nbsp;&nbsp;"; 
 echo "<a href=\"javascript:history.back()\"><strong>GO BACK</strong></a>";
 echo "&nbsp;&nbsp;&nbsp;&nbsp;"; 
 echo "<a href=$self?userid=''&password=''>LOGOUT</a>";
 echo "</H3>\n";

 echo "<table cellpadding=0 cellspacing=0 border=1>\n";
 echo "<tr>\n";
 for ($c=0;$c<$numfields;++$c) {
   $lastfield = trim(mysql_field_name($result,$c));
   echo "<th>&nbsp;";
   echo $lastfield;
   echo "&nbsp;</th>";
 }
 echo "</tr>\n";

 while($rows < $count) {
   $list = mysql_fetch_assoc($result);
   echo "<tr>\n";
   for($c=0;$c<$numfields;++$c) {
     $d = $list[mysql_field_name($result,$c)];
     echo "<td>&nbsp;";  
     if (strtolower($lastfield) == "database") {
       $query = "show tables from " . $d;
       $query = urlencode($query);
       echo "<a href=$self?query=$query>";
       echo $d;
       echo "</a>";
     }
     else {
       if (strtolower(substr($lastfield,0,10)) == "tables_in_") {
         $query = "show create table " . strtolower(substr($lastfield,10)) . "." . $d;
         $query = urlencode($query);
         echo "<a href=$self?query=$query>";
         echo "[show create]";
         echo "</a>";
         echo "&nbsp;&nbsp;";
         $query = "select * from " . strtolower(substr($lastfield,10)) . "." . $d;
         $query = urlencode($query);
         echo "<a href=$self?query=$query>";
         echo "[select *]";
         echo "</a>";
         echo "&nbsp;&nbsp;";
         $query = "show columns from " . strtolower(substr($lastfield,10)) . "." . $d;
         $query = urlencode($query);
         echo "<a href=$self?query=$query>";
         echo "[show columns]";
         echo "</a>";
         echo "&nbsp;&nbsp;";
         echo $d;
       }
       else echo $d;
     } 
     echo "&nbsp;</td>\n";
   }
   echo "</tr>\n";
   $rows++;
 }
 echo "</table>\n";
}
  session_start();
  include('header.php');
  $hn = "localhost";
  $un = "root";
  $ps = "";
  if (isset($_POST['userid'])) {
    $_SESSION['mysqluserid']   = $_POST['userid'];
    $_SESSION['mysqlpassword'] = $_POST['password'];
  }
  else {
    if (isset($_GET['userid'])) {
      unset($_SESSION['mysqluserid']);
      unset($_SESSION['mysqlpassword']);
    }
  }
  if (isset($_SESSION['mysqlpassword'])) { 
    $un = $_SESSION['mysqluserid'];
    $ps = $_SESSION['mysqlpassword'];
  }

 echo "<center>";

 $self = $_SERVER['PHP_SELF'];
 if ( (!isset($_POST['submit'])) && (!isset($_GET['query']))  ) {
   echo "<H2>MySQL Query</H2>\n";
   echo "<form method=post action=$self>\n";
   echo "Query ->&nbsp; <input type=text size=70  name=query value=\"show databases\">\n";
   if (!isset($_SESSION['mysqlpassword'])) { 
     echo "<br><br>\n";
     echo "Userid <INPUT input type=text size=20 name=\"userid\"> &nbsp;&nbsp;";
     echo "Password <INPUT input type=password size=20 name=\"password\">";
   }
   echo "<br><br>\n";
   echo "<input type=submit name=submit value=submit>\n";
   echo "&nbsp;&nbsp&nbsp;&nbsp;\n";
   echo "<input type=reset  value=reset>\n";
   echo "</form>\n";
   echo "<h4>Examples:</h4>";
   echo "<br>ALTER TABLE `db.table` ADD `id` INT( 10 ) UNSIGNED AFTER `uniqueid`";
   echo "<br>SELECT * FROM db.table where name like '%name%' order by id";
   echo "<br>SHOW COLUMNS FROM FROM db.table";
   echo "<br>SHOW CREATE TABLE db.table";
   echo "<br>DROP TABLE IF EXISTS db.table";
   echo "<br>UPDATE db.table set name='' where id='5'";
   echo "<br>DELETE FROM db.table where id='5'";
   echo "<br>INSERT INTO db.table (name,id) values ('name','33')";
 }
 else { 
   $mylink = mysql_connect($hn,$un,$ps);
   if (!$mylink) {
     unset($_SESSION['mysqlpassword']);  
     unset($_SESSION['mysqluserid']);  
     die("Error: can not connect to server\n");
   }
   if (isset($_GET['query'])) $query = $_GET['query'];
   else                       $query = $_POST['query'];
   make_table($query);
   mysql_close($mylink);
   echo "<br>";
   echo "<form method=post action=$self>\n";
   echo "Query ->&nbsp; <input type=text size=70  name=query value=\"$query\">\n";
   echo "<br><br>\n";
   echo "<input type=submit name=submit value=submit>\n";
   echo "&nbsp;&nbsp&nbsp;&nbsp;\n";
   echo "<input type=reset  value=reset>\n";
   echo "</form>\n";
 }
 echo "</center></body></html>";
?>
