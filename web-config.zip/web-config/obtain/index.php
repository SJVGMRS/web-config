<html>
<head>
<title>Asterisk WEB/PHP Management Interface: PHP Scripts for Managing Asterisk realted functions via the Web Copyright (C) 2005-2007 Earl C. Terwilliger</title>
</head>
<body>
<center>
<a href="http://asterisk.org"><img src=asterisk-logo.gif border=0></a><br><br>
Asterisk WEB/PHP Management Interface Copyright (C) 2005-2007 Earl C. Terwilliger
</center>
<br>
<p>The Asterisk WEB/PHP Management Interface was created to allow easy management of Asterisk Functions through a WEB interface. It is released under the GNU GPL license.</p>

<br>
<p>Download the latest tar file here: <a href=http://www.micpc.com/astwebmgr/astwebmgr.tar.gz>astwebmgr.tar.gz</a>&nbsp;&nbsp;&nbsp;&nbsp;You can contact the author at: <a href="mailto:earl@micpc.com">earl@micpc.com</a></p>
<br>

<center>
<p>Your PayPal donation of any amount will help to support this project. THANKS!</p>

<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but04.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
<input type="hidden" name="encrypted" value="-----BEGIN PKCS7-----MIIHJwYJKoZIhvcNAQcEoIIHGDCCBxQCAQExggEwMIIBLAIBADCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwDQYJKoZIhvcNAQEBBQAEgYCxRgyRCP8Z12qo2lxUyfxYonaIrky8grX+WSYpFCdRu3DAUKClOxrwt27V/HXYGgq1Q3U2fH4lHf9Iyi7Z8VymRXSnk44jrZCGo8XAH7PwNvVmjuhnUwnQSI06vmJGgcEn40MnBq1rSkYTUv1/Ea+5AUxk+XQolNp2noVLjuVANTELMAkGBSsOAwIaBQAwgaQGCSqGSIb3DQEHATAUBggqhkiG9w0DBwQIZRm0tPlMgWGAgYD5dsSclGkMHJiwRnp1ZcA7BEblJAR34HNITkMk7ZBhQMrrqIvFWl+WOgL19iBXWZCsrAfx7f8xgNmmAsYVfRac7MlconeXTZChIRBQDoYHe9dMqc4zuHVsb0Yu5GAREVS9R1ZFcYNZRYsmvBlwVMpoa+m6uZY7kPIIfU9fji0xMqCCA4cwggODMIIC7KADAgECAgEAMA0GCSqGSIb3DQEBBQUAMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbTAeFw0wNDAyMTMxMDEzMTVaFw0zNTAyMTMxMDEzMTVaMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbTCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAwUdO3fxEzEtcnI7ZKZL412XvZPugoni7i7D7prCe0AtaHTc97CYgm7NsAtJyxNLixmhLV8pyIEaiHXWAh8fPKW+R017+EmXrr9EaquPmsVvTywAAE1PMNOKqo2kl4Gxiz9zZqIajOm1fZGWcGS0f5JQ2kBqNbvbg2/Za+GJ/qwUCAwEAAaOB7jCB6zAdBgNVHQ4EFgQUlp98u8ZvF71ZP1LXChvsENZklGswgbsGA1UdIwSBszCBsIAUlp98u8ZvF71ZP1LXChvsENZklGuhgZSkgZEwgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tggEAMAwGA1UdEwQFMAMBAf8wDQYJKoZIhvcNAQEFBQADgYEAgV86VpqAWuXvX6Oro4qJ1tYVIT5DgWpE692Ag422H7yRIr/9j/iKG4Thia/Oflx4TdL+IFJBAyPK9v6zZNZtBgPBynXb048hsP16l2vi0k5Q2JKiPDsEfBhGI+HnxLXEaUWAcVfCsQFvd2A1sxRr67ip5y2wwBelUecP3AjJ+YcxggGaMIIBlgIBATCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwCQYFKw4DAhoFAKBdMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTA1MDQyMjE4MzY1OVowIwYJKoZIhvcNAQkEMRYEFC0CAOio+skgECdqjVNnP5wWWPP9MA0GCSqGSIb3DQEBAQUABIGAsEGXD99+4grJ7fi6Xc18VjS4qrksyoSjbx47igetHhr+QvRBUeKEcizmok/jCaGYNV9WrwXm+8oO0muEo67b+m50r1ESIhaBP6LsTOP4FnemNgwu4At/Ii3YBd3AlM8OzyXXZxbRnjMSN+9MchgidW2T45F688e+RV572Z57bIg=-----END PKCS7-----
">
</form>
</center>
<hr>
</body>
</html>
