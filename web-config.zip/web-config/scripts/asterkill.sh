#!/bin/bash
/bin/ps -ef | /bin/grep "asterstart"  | /bin/grep -v grep | /bin/awk '{ print $2 }' | /usr/bin/xargs /bin/kill -9 
/bin/ps -ef | /bin/grep "ProxyMan.py" | /bin/grep -v grep | /bin/awk '{ print $2 }' | /usr/bin/xargs /bin/kill -9 
/bin/ps -ef | /bin/grep "mpg123"      | /bin/grep -v grep | /bin/awk '{ print $2 }' | /usr/bin/xargs /bin/kill -9 
/bin/ps -ef | /bin/grep "asterisk"    | /bin/grep -v grep | /bin/awk '{ print $2 }' | /usr/bin/xargs /bin/kill -9 
/bin/ps -ef | /bin/grep "mpg123"      | /bin/grep -v grep | /bin/awk '{ print $2 }' | /usr/bin/xargs /bin/kill -9 
