/*
   Earl Terwilliger
   earl@micpc.com   
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define BUFSIZE 1024

#define PROCESS_CHECK "/bin/ps -ef | /bin/grep \"asterisk\" | /bin/grep -v grep | /bin/awk '{ print $8 }'"
#define RENICE   "/usr/bin/renice -15 -p `cat /var/run/asterisk.pid`"
#define PROCESS  "/usr/sbin/asterisk"
#define PROCESS1 "/opt/asterisk/scripts/events/ProxyMan.py"

int main() {

  FILE *read_fp;
  char buffer[BUFSIZE + 1],*ptr;
  int chars_read,pid;

  pid  = fork();
  if (pid < 0) exit(1);
  if (pid > 0) exit(0);
  
  while (1) {
    memset(buffer, '\0', sizeof(buffer));
    read_fp = popen(PROCESS_CHECK, "r");
    if (read_fp != NULL) {
      chars_read = fread(buffer, sizeof(char), BUFSIZE, read_fp);
      buffer[chars_read] = (char)'\0';
      pclose(read_fp);
    }
    ptr = strstr(buffer,PROCESS);
    if (ptr == NULL) {
      system(PROCESS);
      system(RENICE);
      sleep(2);
      system(PROCESS1);
    }
    sleep(15);
  }

  exit(0);
}
    
