<?php
/* 
 Copyright (C) 2006 Earl C. Terwilliger
 Email contact: earl@micpc.com

 Name : sysfork.php 
 Usage: PHP script to run system commands in the background

    This file is part of The Asterisk WEB/PHP Management Interface.

    These files are free software; you can redistribute them and/or modify
    them under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    These programs are distributed in the hope that they will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with these files (see COPYING); if not, write to the:

         Free Software Foundation, Inc.
         59 Temple Place
         Suite 330
         Boston, MA  02111-1307
         USA
*/
include('header.php');
if (isset($_GET['cmd']))     $cmd   = $_GET['cmd'];
if (isset($_POST['cmd']))    $cmd   = $_POST['cmd'];
echo '<pre>';
echo $cmd;
echo "</pre>";
$cmd = "sudo " . $cmd . " > /dev/null 2>&1 &";
exec($cmd);
?>
